package UI;


public abstract class FunctionalMenuItem extends MenuItem {
    public FunctionalMenuItem(String name) {
        super(name);
    }
}
