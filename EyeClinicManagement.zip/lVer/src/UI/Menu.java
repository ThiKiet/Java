package UI;

import commons.Doctor;
import commons.PriceList;
import commons.Human;
import commons.Patient;
import static commons.PriceList.drugs;
import commons.UserManagement;
import static commons.UserManagement.doctorList;

import javax.print.Doc;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

public class Menu {

    private static final FunctionalMenuItem functionDeletePatient = new FunctionalMenuItem("Delete user") {
        @Override
        public void execute() {
            Scanner input = new Scanner(System.in);
            Patient searchResult;
            String username;

            System.out.print("\nType username of the account you want to delete... Leave blank to cancel: ");
            username = input.nextLine();
            searchResult = UserManagement.getPatientByUserName(username);

            while (searchResult == null) {
                if (username.equals("")) {
                    return;
                }
                System.out.print("\nWrong username... Retype... Leave blank to cancel. : ");
                username = input.nextLine();
                searchResult = UserManagement.getPatientByUserName(username);
            }


            if (searchResult != null) {
                UserManagement.removePatient(username);
                System.out.println("Deleted successfully!");
            }
        }
    };
    
    
    private static final FunctionalMenuItem functionDeleteDoctor = new FunctionalMenuItem("Delete user") {
        @Override
        public void execute() {
            Scanner input = new Scanner(System.in);
            Doctor searchResult;
            String username;

            System.out.print("\nType username of the account you want to delete... Leave blank to cancel: ");
            username = input.nextLine();
            searchResult = UserManagement.getDoctorByUserName(username);

            while (searchResult == null) {
                if (username.equals("")) {
                    return;
                }
                System.out.print("\nWrong username... Retype... Leave blank to cancel. : ");
                username = input.nextLine();
                searchResult = UserManagement.getDoctorByUserName(username);
            }


            if (searchResult != null) {
                UserManagement.removeDoctor(username);
                System.out.println("Deleted successfully!");
            }
        }
    };

    // THÊM BỆNH NHÂN
    private static final FunctionalMenuItem functionAddPatient = new FunctionalMenuItem("Add Patient") {
        @Override
        public void execute() {

            String name;
            String username;
            Date dob;
            String IdCard;
            String password;
            String Address;
            Scanner input = new Scanner(System.in);
            System.out.print("\n\t\t\tYou are inserting patient's information");
            System.out.print("\n\n\t\t\tEnter the information below: ");
            Patient searchResult;
            
            do {
                System.out.print("\n\t\t\t\tUsername: ");
                username = input.nextLine();
                searchResult = UserManagement.getPatientByUserName(username);
                //System.out.println(searchResult);
            } while (searchResult != null);
            System.out.print("\n\t\t\t\tPatient's name: ");
            name = input.nextLine();
            System.out.print("\n\t\t\t\tDate of birth: ");
            dob = new Date();
            input.nextLine();
            System.out.print("\n\t\t\t\tIdCard: ");
            IdCard = input.nextLine();
            System.out.print("\n\t\t\t\tAddress: ");
            Address = input.nextLine();
            do {
                System.out.print("\n\t\t\t\tPassword: ");
                password = input.nextLine();
            } while (password.length() < 8);

            Patient patient = new Patient(name, dob, IdCard, Address, username, password);

            UserManagement.addPatient(patient);
            System.out.println("Add a patient successfully");

            if (UserManagement.patientList.size() > 0) {
                System.out.println("\n\t\t\tCurrently there are :" + UserManagement.patientList.size() + " patient: ");
                for (Doctor account : doctorList) {
                    System.out.println("|Name\t\t|Date of Birth\t\t\t\t\t|Username\t\t|major");
                    UserManagement.showDoctor(account);
                }
            } else {
                System.out.println("\n Currently there aren't any patients recorded. \n");
            }

        }
    };

    // THÊM BÁC SĨ
    private static final FunctionalMenuItem functionAddDoctor = new FunctionalMenuItem("Add Doctor") {
        @Override
        public void execute() {
            String name;
            String username;
            Date dob;
            String IdCard;
            String password;
            String  Address;
            String  major;
            Scanner input = new Scanner(System.in);
            System.out.print("\n\t\t\t\t\tYou are inserting doctor's information");
            System.out.print("\n\n\t\t\t\t\tEnter the information below: ");
            
            Doctor searchResult;
            do {
                System.out.print("\n\t\t\t\t\t\tDoctor's username: ");
                username = input.nextLine();
                searchResult = UserManagement.getDoctorByUserName(username);
                //System.out.println(searchResult);
            } while (searchResult != null);
            
            System.out.print("\n\t\t\t\t\t\tDoctor's name: ");
            name = input.nextLine();
            System.out.print("\n\t\t\t\t\t\tDate of birth: ");
            dob = new Date();
            input.nextLine();
            System.out.print("\n\t\t\t\t\t\tIdCard: ");
            IdCard = input.nextLine();
            System.out.print("\n\t\t\t\t\t\tAddress: ");
            Address = input.nextLine();
            
            do
            {
                System.out.print("\n\t\t\t\t\t\tPassword: ");
                password = input.nextLine();
            } while(password.length() < 10);

            System.out.print("\n\t\t\t\t\t\tMajor: ");
            major = input.nextLine();
            Doctor doctor = new Doctor(name, dob, IdCard, Address, username, password, major);
            UserManagement.addDoctor(doctor);

            if (UserManagement.doctorList.size() > 0) {
                System.out.println("\n\n\t\t\t\t\tDOCTOR'S INFORMATION\n");
                System.out.println("\nCurrently there are :" + UserManagement.doctorList.size() + " doctor: \n");
                for (Doctor account : doctorList) {
                    System.out.println("|Name\t\t|Date of Birth\t\t\t\t\t|Username\t\t|major");
                    UserManagement.showDoctor(account);
                }
            } else {
                System.out.print("\n\t\t\tCurrently there aren't any doctor recorded.\n");
            }

        }
    };

    // TÌM KIẾM NGƯỜI DÙNG
    private static final FunctionalMenuItem functionShowDoctorDetail = new FunctionalMenuItem("Search DOCTOR and view DOCTOR's detail") {
        @Override
        public void execute() {
                System.out.print("\nEnter the username to research: ");
                // tự làm đi
                String username;
                Scanner input = new Scanner(System.in);
                Doctor searchResult;
                username = input.nextLine();
                searchResult = UserManagement.getDoctorByUserName(username);
                while (searchResult == null) {
                    if (username.equals("")) {
                        return;
                    }
                    System.out.print("\nNOT FOUND... Retype... Leave blank to cancel. : ");
                    username = input.nextLine();
                    searchResult = UserManagement.getDoctorByUserName(username);
                }


                if (searchResult != null) {
                    UserManagement.showDoctor(searchResult);
                    System.out.println("SEARCH Doctor successfully!");
                }

        }
    };

    
        private static final FunctionalMenuItem functionShowPatientDetail = new FunctionalMenuItem("Search DOCTOR and view DOCTOR's detail") {
        @Override
        public void execute() {
            System.out.print("\nEnter the username to research: ");
            
            String username;
            Scanner input = new Scanner(System.in);
            Patient searchResult;
            username = input.nextLine();
            searchResult = UserManagement.getPatientByUserName(username);
            while (searchResult == null) {
                if (username.equals("")) {
                    return;
                }
                System.out.print("\nNOT FOUND... Retype... Leave blank to cancel. : ");
                username = input.nextLine();
                searchResult = UserManagement.getPatientByUserName(username);
            }


            if (searchResult != null) {
                UserManagement.showPatient(searchResult);
                System.out.println("SEARCH Patient successfully!");
            }
        }
    };
    
    
    // SỬA THÔNG TIN BỆNH NHÂN
    private static final void updatePatient(Patient patient) {
            
        };

    // SỬA THÔNG TIN BÁC SĨ
    private static final void updateDoctor(Doctor doctor) {

    };

    // SỬA THÔNG TIN NGƯỜI DÙNG

//    private static final FunctionalMenuItem functionUpdateUser = new FunctionalMenuItem("Update user") {
//        @Override
//        public void execute() {
//            Scanner input = new Scanner(System.in);
//            System.out.print("\nEnter the username to edit: ");
//            String username = input.nextLine();
//            Human searchResult = UserManagement.getUserByUserName(username);
//1
//            while (searchResult == null) {   //báo sai username, nhập lại
//                System.out.println("Wrong username. Retype:");
//                username = input.nextLine();
//                searchResult = UserManagement.getUserByUserName(username);
//            }
//
//            if (searchResult instanceof Patient) {
//                updatePatient(searchResult);
//
//            } else { //HIện form bác sĩ ra
//                System.out.println("nncb");
//                //functionUpdateDoctor();
//
//            }
//
//
//        }
//    };

    private static final FunctionalMenuItem functionShowUser = new FunctionalMenuItem("Show user") {
        @Override
        public void execute() {
            System.out.println("hihi delete");
        }
    };

    private static final FunctionalMenuItem functionSearchDrug = new FunctionalMenuItem("Search drug") {
        @Override
        public void execute() {
           
        }
    };

    private static final FunctionalMenuItem functionShowDrug = new FunctionalMenuItem("Show drug") {
        @Override
        public void execute() {
            PriceList tr = new PriceList();
            tr.printDrug();
            
        }
    };
    private static final FunctionalMenuItem functionShowService = new FunctionalMenuItem("Show service") {
        @Override
        public void execute() {
            PriceList tr = new PriceList();
            tr.Printservices();
            
        }
    };


    public static CategoryMenuItem menuItems = new CategoryMenuItem("Menu",
            new MenuItem[]{

                    new CategoryMenuItem("User management",
                            new MenuItem[]{
                                    new CategoryMenuItem("Doctor management",
                                            new MenuItem[]{
                                                    //functionAddPatient, functionDeleteUser
                                                    functionAddDoctor,
                                                    functionDeleteDoctor,
                                                    functionShowDoctorDetail
                                            }),
                                    new CategoryMenuItem("Patient management",
                                            new MenuItem[]{
                                                    functionAddPatient, 
                                                    functionDeletePatient,
                                                    functionShowDoctorDetail
                                            }
                                    )
                            }

                    ),

                    new CategoryMenuItem("Drug management",
                            new MenuItem[]{
                                    functionShowDrug,
                                    functionSearchDrug,
                            }),
                    new CategoryMenuItem("Show services",
                            new MenuItem[]{
                                functionShowService
                            }),

                    new FunctionalMenuItem("Close the program"
                    ) {
                        @Override
                        public void execute() {
                            System.exit(0);
                        }
                    }
            }

    );
}
