package UI;

import java.awt.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class CategoryMenuItem extends MenuItem {

    private MenuItem[] menuItems;

    public CategoryMenuItem(String name, MenuItem[] menuItems) {
        super(name);
        this.menuItems = menuItems;
    }

    @Override
    public void execute() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\t\t\t\t**************************************************\n\n");
        int choice = 0;
        do {

            for (int i = 0; i < this.menuItems.length; i++) {
                System.out.print("\t\t\t\t\t\t");
                System.out.print(i+1 + ". " + this.menuItems[i].getName() + "\n\n");
            }

            try {
                System.out.print("\t\t\t\t\t\tChoose number: ");
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                continue;
            }

            if (choice> 0 && choice <= menuItems.length)this.menuItems[choice - 1].execute();

        }   while (choice != 0) ;
    }
}
