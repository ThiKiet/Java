import UI.Menu;
import commons.Human;
import commons.Patient;
import commons.UserManagement;

import java.util.Scanner;

//import UI.Menu;
//
public class Main {
//
    public static void main(String[] args) {

        Menu.menuItems.execute();
    }
    
//    public static void main(String[] args) {
//        Scanner input = new Scanner(System.in);
//       String username = "";
//            System.out.println("Who do you want to delete? ");        
//            username = input.nextLine();
//            Human searchResult = UserManagement.getUserByUserName(username);
//
//            if (searchResult == null) {
//                System.out.println("Wrong user! Please enter the username again!"); 
//               }else if (searchResult instanceof Patient) {
//                   
//                  UserManagement.removeUser(username);
//                   
//                  
//                   
//            } else {
//                   
//            }
//        
//        UserManagement.showUser();
//    }
}

