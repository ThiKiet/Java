package commons;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

public class UserManagement {
    public static ArrayList<Doctor>doctorList = new ArrayList<Doctor>() {
        {
            
         add(new Doctor("Kiet", new Date(),"197392454","QTQN", "meo", "1234","Y học cổ truyền"));
         add(new Doctor("Thuong", new Date(),"645767","QTBN", "chuot", "1234","Y học cổ truyền"));
         
        }
    };

    
    public static ArrayList<Patient>patientList = new ArrayList<Patient>() {
        {
            
         add(new Patient("Hung", new Date(),"197392454","Q", "hung", "1234"));
         add(new Patient("Tuan", new Date(),"645767","DN", "tuan", "1234"));
         
        }
    };
    
    public static void addDoctor(Doctor doctor) {
        doctorList.add(doctor);
    }

    public static void addPatient(Patient patient) {
        patientList.add(patient);
    }
    
    public static void removeDoctor(String username) {
        //userList.removeIf(human -> human.getUsername().equals(username));
        
         Iterator<Doctor> itr = doctorList.iterator(); 
        while (itr.hasNext()) { 
        Human text = itr.next(); 
        
            if (text.getUsername().equals(username)) { 
                itr.remove(); 

            }     
        }   
    }
    
    public static void removePatient(String username) {
        //userList.removeIf(human -> human.getUsername().equals(username));
        
         Iterator<Patient> itr = patientList.iterator(); 
        while (itr.hasNext()) { 
        Human text = itr.next(); 
        
            if (text.getUsername().equals(username)) { 
                itr.remove(); 

            }     
        }   
    }

    public static void editDoctor(Doctor doctor) {
        doctorList.replaceAll(user -> (user.getUsername().equals(doctor.getUsername()) ? doctor : user) );
//        userList.set(userList.indexOf(getUserByUserName(username)), human);
    }
    
    public static void editPatient(Patient patient) {
        patientList.replaceAll(user -> (user.getUsername().equals(patient.getUsername()) ? patient : user) );
//        userList.set(userList.indexOf(getUserByUserName(username)), human);
    }
    

    public static Doctor getDoctorByUserName(String username) {
        for (Doctor account : doctorList) {
            String checkUserName = account.getUsername();
            if(account.getUsername().equals(username)) {
                return account;
            }
        }
        return null;
    }
    
    public static Patient getPatientByUserName(String username) {
        for (Patient account : patientList) {
            String checkUserName = account.getUsername();
            if(account.getUsername().equals(username)) {
                return account;
            }
        }
        return null;
    }
    
    public static  void showPatient(Patient patient) {
      
        System.out.println(patient.toString());
        
                
    
    }
    
    public static  void showDoctor(Doctor doctor) {
      
        System.out.println(doctor.toString());

    }
}
