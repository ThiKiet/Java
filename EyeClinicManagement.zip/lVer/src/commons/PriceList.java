package commons;

class Drug {
    public String name;
    public double price;

    public Drug(String name, double price) {
        this.name = name;
        this.price = price;
    }
}

class Service {
    public String name;
    public double price;

    public Service(String name, double price) {
        this.name = name;
        this.price = price;
    }
}


public class PriceList {
    public static Drug[] drugs = {
            new Drug("Eye drops",5000),   //Thuốc nhỏ mắt
            new Drug("Eye tonic", 10000), //Thuốc bổ mắt
            new Drug("Another drugs", 400000)
    };
    
    public void printDrug() {
        System.out.println("Name \t\t\t\tPrice");
        for (int i = 0; i < drugs.length; i++) {
            Drug d = drugs[i];
            System.out.println(d.name + "\t\t\t" + d.price + "\n");
        
        }
    }

    public static Service[] services = {
            new Service("Myopic surgery ", 900000),      //phẫu thuật cận thị
            new Service("Presbyopia surgery", 12091209), //..........viễn thị
            new Service("Astigmatism surgery", 40000000) //..........loạn Thị
    };
    
    public void Printservices() {
        System.out.println("Name \t\t\t\tPrice");
        for (int i = 0; i < services.length; i++) {
            Service d = services[i];
            System.out.println(d.name + "\t\t\t" + d.price + "\n" );
        }
        
    }
    
    public static Drug getDrug(int id) {
        return drugs[id];
    }

    public static Service getService(int id) {
        return services[id];
    }
}
