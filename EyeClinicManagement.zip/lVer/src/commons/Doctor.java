package commons;

import java.util.Date;
import java.util.Scanner;

public class Doctor extends Human {

    private String major;

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {

        this.major = major;
    }

    public Doctor(String name, Date dob, String idCard, String address, String usename, String password, String major) {
        super(name, dob, idCard, address, usename, password);
        this.major = major;
    }

    @Override
    public String toString() { 
        return "\t\t\t|" + this.getName() + "\t\t|" + this.getDob() + "\t\t\t|" +this.getUsername()+
                "\t\t\t|'" + major + '\'' + "|\n";
    }



}
