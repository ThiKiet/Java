
package commons;

import java.util.Arrays;
import java.util.Date;

public class Record {
    private Date date;
    private boolean[] serviceDetail;
    private int[] drugDetail;
    private String diagnose;
    private Doctor doctor;

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        this.doctor = doctor;
    }

    public Record(Date date, boolean[] serviceDetail, int[] drugDetail, String diagnose, Doctor doctor) {
        this.date = date;
        this.serviceDetail = serviceDetail;
        this.drugDetail = drugDetail;
        this.diagnose = diagnose;
        this.doctor = doctor;
    }

    public Record(Date date, boolean[] serviceDetail, int[] drugDetail, String diagnose) {
        this.date = date;
        this.serviceDetail = serviceDetail;
        this.drugDetail = drugDetail;
        this.diagnose = diagnose;
    }
    public Record(Date date, Doctor doctor) {
        this.date = date;
        this.doctor = doctor;
    }
    public String getDiagnose() {
        return diagnose;
    }

    public void setDiagnose(String diagnose) {
        this.diagnose = diagnose;
    }



    public Record(Date date, boolean[] serviceDetail, int[] drugDetail) {
        this.date = date;
        this.serviceDetail = serviceDetail;
        this.drugDetail = drugDetail;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean[] getServiceDetail() {
        return serviceDetail;
    }

    public void setServiceDetail(boolean[] serviceDetail) {
        this.serviceDetail = serviceDetail;
    }

    public int[] getDrugDetail() {
        return drugDetail;
    }

    public void setDrugDetail(int[] drugDetail) {
        this.drugDetail = drugDetail;
    }

    public void addNewService(int id) {
        this.serviceDetail[id] = true;
    }

    public void addNewDrug(int id, int quantity) {
        this.drugDetail[id] = quantity;
    }

    public double getTotal() {
        double total = 0;

        for (int drugId = 0; drugId < PriceList.drugs.length; drugId++) {
            total += PriceList.getDrug(drugId).price * this.drugDetail[drugId];
        }
        for (int serviceId = 0; serviceId < PriceList.services.length; serviceId++) {
            total = this.serviceDetail[serviceId] ? total + PriceList.getService(serviceId).price : total;
        }
        return total;
    }

    @Override
    public String toString() {
        return "Record{" +
                "date=" + date +
                ", serviceDetail=" + Arrays.toString(serviceDetail) +
                ", drugDetail=" + Arrays.toString(drugDetail) +
                ", diagnose='" + diagnose + '\'' +
                '}';
    }
    
    
}
