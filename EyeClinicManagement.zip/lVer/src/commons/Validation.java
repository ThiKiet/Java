
package commons;

import java.util.Scanner;

public class Validation 
{
        Scanner input = new Scanner(System.in); 
        //xoá khoảng trắng
        public String standardize(String str) {
            str = str.trim();
            str = str.replaceAll("\\s+", " ");
            return str;
        }

        //in hoa
        public String upCase(String str) 
        {
            str = standardize(str);
            String temp[] = str.split(" ");
            str = ""; 
            for (int i = 0; i < temp.length; i++) 
            {
                str += String.valueOf(temp[i].charAt(0)).toUpperCase() + temp[i].substring(1);
                if (i < temp.length - 1)     str += " ";
            }
            return str;
        }

        //kiểm tra đã nhập tên hay chưa.
        public String testName(String name)
        {
           Scanner input = new Scanner(System.in);
           
            name.trim();
            char kyTu;
            int count = -1, i;
            // duyệt từ đầu đến cuối chuỗi
             
            for (i = 0; i < name.length(); i++) 
            {
                // trả về ký tự tại vị trí thứ i trong chuỗi
                // và gán vào cho biến kyTu
                kyTu = name.charAt(i);
                // kiểm tra ký tự tại vị trí i có phải khoảng trắng không
                if (Character.isSpace(kyTu)) 
                {
                    count = i;
                }
            }  
            
            // nhập chỉ tên hoặc họ thì trả về chưa nhập đủ
           while (count == -1)
            {
		System.out.println("\t\t\t\t\t\tVALUE COULDN'T BE FOUND. PLEASE RETYPE!");
		System.out.print("\t\t\t\t\t\t");
                name = input.nextLine();
                testName(name);
                break;
            } 
            return name;
        }  
     
        
        
        
        public void exit()
        {
            //title();
            System.out.println("\n\t\t\t\t\t      ============ EXIT =========== \n");
            System.out.println("\n\t\t\t\t\t Do you want to exit the program?\n\n\t\t\t\t\t 1. YES.\n\t\t\t\t\t 2. NO.");        
            String c = input.nextLine();

          switch(c)
            {
                  case "1":
                          System.exit(0);
                          break;
                  case "2":
                          //choose();
                          break;
                  default: exit();
            }
        }

}