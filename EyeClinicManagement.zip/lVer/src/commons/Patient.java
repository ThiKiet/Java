package commons;

import java.util.ArrayList;
import java.util.Date;

public class Patient extends Human {
    private ArrayList<Record> records;

    public Patient(String name, Date dob, String idCard, String address, String usename, String password, ArrayList<Record> records) {
        super(name, dob, idCard, address, usename, password);
        this.records = records;
    }

    public Patient(String name, Date dob, String idCard, String address, String usename, String password) {
        super(name, dob, idCard, address, usename, password);
        
    }

    public ArrayList<Record> getRecords() {
        return records;
    }

    public void setRecords(ArrayList<Record> records) {
        this.records = records;
    }

    public void addRecord(Record record) {
        this.records.add(record);
    }

    public Record getRecord(int id) {
        return this.records.get(id);
    }
    
    @Override
    public String toString() {
        return "Patient \n Name: " + this.getName() + "\nDate of Birth: " + this.getDob() + "\nUsername: " +this.getUsername()+
                "\nmajor='";
    }

}
