package commons;

import java.util.Date;

public abstract class Human {
    private String name;
    private Date dob;
    private String idCard;
    private String address;
    private String username;
    private String password;
    
    public Human(){
        
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getName() {
        return name;
    }

    public Date getDob() {
        return dob;
    }

    public String getIdCard() {
        return idCard;
    }

    public String getAddress() {
        return address;
    }

    public String getUsername() {
        return username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Human(String name, Date dob, String idCard, String address, String usename, String password) {
        this.name = name;
        this.dob = dob;
        this.idCard = idCard;
        this.address = address;
        this.username = usename;
        this.password = password;
    }
}
